@ECHO off
set UTOOL=%1
set UTGTIN=%2
set UPRTIN=%3

echo Mode %UTOOL%
if /I "%UTOOL%" == "UART"  Goto contine_UART
if /I "%UTOOL%" == "I2C"   Goto contine_I2C
goto usage

:contine_I2C
set uptool=firmware\winc_programmer_i2c.exe
goto checkdevice

:contine_UART
set uptool=firmware\winc_programmer_uart.exe  -p \\.\COM%UPRTIN%
goto checkdevice

:checkdevice
echo Chip %UTGTIN%
if /I "%UTGTIN%" == "3400"  Goto chip3400
if /I "%UTGTIN%" == "3A0"   Goto chip3A0
if /I "%UTGTIN%" == "1500"  Goto chip3A0
goto usage

:chip3A0
set UVARIANT=3A0
set UCHPFAM=1500
set UPFW=programmer_release_text.bin
goto START

:chip3400
set UVARIANT=3400
set UCHPFAM=3400
set UPFW=programmer_firmware.bin
goto START

:START

echo Updating PLL table in image for %UVARIANT% variant

set xo_off=0x0000

echo %uptool% -d winc%UCHPFAM% -pfw programmer_firmware\release%UVARIANT%\%UPFW% -r efuse -o efuse.tmp -of efuse_active
%uptool% -d winc%UCHPFAM% -pfw programmer_firmware\release%UVARIANT%\%UPFW% -r efuse -o efuse.tmp -of efuse_active

if %ERRORLEVEL% neq 0 (
    endlocal
    exit /b 1
)

if exist efuse.tmp (
    for /F "tokens=2 " %%a in ('findstr "EFUSE_XO_OFFSET:" efuse.tmp') do set xo_off=%%a
    del efuse.tmp
)

echo XO Offset is %xo_off%

echo firmware\image_tool.exe -c firmware\flash_image.config  -c Tools\gain_builder\gain_sheets\samd21_gain_setting_hp.config  -cs "[pll table]\r\nfrequency offset is %xo_off%\r\n"  -o firmware\m2m_image_%UVARIANT%.bin -of prog 
firmware\image_tool.exe -c firmware\flash_image.config  -c Tools\gain_builder\gain_sheets\samd21_gain_setting_hp.config  -cs "[pll table]\r\nfrequency offset is %xo_off%\r\n"  -o firmware\m2m_image_%UVARIANT%.bin -of prog 

echo firmware\image_tool.exe -c firmware\flash_image.config  -c Tools\gain_builder\gain_sheets\samd21_gain_setting_hp.config  -cs "[pll table]\r\nfrequency offset is %xo_off%\r\n"  -o firmware\m2m_image_%UVARIANT%.aoi -of raw >NUL
firmware\image_tool.exe -c firmware\flash_image.config  -c Tools\gain_builder\gain_sheets\samd21_gain_setting_hp.config  -cs "[pll table]\r\nfrequency offset is %xo_off%\r\n"  -o firmware\m2m_image_%UVARIANT%.aoi -of raw >NUL

if not ERRORLEVEL 0 GOTO failure

set xo_off=
goto done

:USAGE
echo Usage %0 (I2C or UART) (1500 or 3400) (comport or 0 for I2C)
@ECHO %CMDCMDLINE% | FIND /I /C "/C" > NUL && PAUSE
exit /b -1

:failure
echo Unsuccessful
set xo_off=
exit /b -1

:done
echo Successful
